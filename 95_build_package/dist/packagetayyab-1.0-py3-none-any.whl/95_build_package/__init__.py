def func(num):
    print("this is the function")
    return num

